const readline = require('readline')

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question('Informe um n�mero: ', (num) => {

    for (let i = 0; i <= num; i++) {
        if (i == 0) {
            console.log(i + ' ZERO');
        } else if (i % 2 == 0) {
                    console.log(i + ' PAR');
                } else {
                    console.log(i + ' IMPAR');
                }
            }

        rl.question('Pressione Enter para finalizar...\n', function () {
            rl.close();
  
    });
});
