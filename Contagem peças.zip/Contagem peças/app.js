const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
})

rl.question('Informe o nome da pe�a: ', (nome) => {

    if (nome.length > 3) {
        rl.question('Informe o peso da pe�a: ', (peso) => {
            if (peso <= 100) {
                rl.question('Informe a quantidade: ', (qtd) => {
                    if (qtd <= 10) {
                        console.log('Pe�a cadastrada');
                        rl.question('Pressione enter para finalizar... \n', function () {
                            rl.close();
                        });
                    } else {
                        console.log('Quantidade superior a permitida');
                        rl.question('Pressione enter para finalizar... \n', function () {
                            rl.close();
                        });
                    }
                });
            } else {
                console.log('Peso acima do limite');
                rl.question('Pressione enter para finalizar... \n', function () {
                    rl.close();
                });
            }
        });
    } else {
        console.log('Nome informado � curto');
        rl.question('Pressione enter para finalizar... \n', function () {
            rl.close();
        });
    }
});

